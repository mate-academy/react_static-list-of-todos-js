// Add the required props
export const UserInfo = ({ user }) => (
  <div className="UserInfo">
    {user.name}
    {user.email}
  </div>
);
