import { UserInfo } from "../UserInfo/UserInfo";

// Add the required props
export const TodoInfo = ({ todo }) => <li className={`TodoInfo ${todo.completed ? 'TodoInfo--completed' : ''}`} >
  {todo.title}
  {todo.user && <UserInfo user={todo.user}/>}
</li>;
